<<<<<<< HEAD
# JavaPasswordRecovery
=======
<<<<<<< HEAD
# JavaPasswordRecovery
=======
# Technical task

## Functions of the different foles
1. User or admin can register to the system and program can enter their to the DB (PostgreSQL)
2. User or admin can login to their accounts by their ID or email
3. Admin can create new users directly in the DB and also delete their
4. User can delete only his account

## Internal program features
1. Password is saved in hashed form
2. DB must save unique user id
3. Password must satisfy the criteria:
    - Contain at least 6 symbols
    - Contain 1 digit, 1 uppercase and lowercase, 1 extra symbol
>>>>>>> 65bcd32 (Java complete project)
>>>>>>> 37493f3 (Java Recovery Project complete)
